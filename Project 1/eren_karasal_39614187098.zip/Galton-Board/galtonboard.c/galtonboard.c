#include <stdio.h>
#include <stdlib.h>
#include <time.h>

//Description 
// This is galton board is counting balls which cpu can create as much as .
// We have 20 row and 1.000.000 balls but cpu can not counting 1.000.000 balls .
// This is the description of my CPU s capacity .



void galton(int boxcount,int ballcount,int *galton_arr)
{
    int box[20];
    int left_or_right = 0;
    int counter;
    int i, j;

    srand(time(NULL));

    for (i = 0; i < 20; i++)
    {
        box[i] = 0;
    }

    for (i = 0; i < 1000000; i++)
    {
        counter = 0;
        for (j = 0; j < 20 - 1; j++)
        {
            left_or_right = rand() % 2;
            counter = counter + left_or_right;
        }
        box[counter] = box[counter]++;
    }

    for (i = 0; i < 20; i++)
    {
        galton_arr[i] = box[i];
    }

    return;
}

int main(int argc, char **argv)
{
    char line[] = " +-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-->";
    char numbers[] = " 0     5     10     15     20     25     30     35     40     45     50";

    int boxcount = 20;
    int ballcount = 1000000;
    int galton_arr[20];
    int i, j;

    printf("%s\n%s\n", numbers, line);

    galton(boxcount, ballcount, galton_arr);

    for (i = 0; i < 20; i++)
    {
        printf("%d |", i);
        for (j = 0; j < galton_arr[i]; j++)
        {
            printf("#");
        }
        printf(" %d\n%s\n", galton_arr[i], line);
    }

    return 0;
}

